"use client";

import { useState, useRef, useEffect } from "react";
import { useRouter } from "next/navigation";
import {
  Play, Pause, SkipBack, Trash2, Plus, Video, Type, Music,
  Image as ImageIcon, UploadCloud, Settings, Download,
  ZoomIn, ZoomOut, Loader2, X, SlidersHorizontal, ArrowUp, ArrowDown, ChevronDown, Layers, Film, Mic, Magnet, Check
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useClient } from "@/hooks/useClient";
import { supabase } from "@/lib/supabase";
import { FFmpeg } from '@ffmpeg/ffmpeg';
import { fetchFile, toBlobURL } from '@ffmpeg/util';

interface MediaAsset {
  id: string;
  type: "video" | "image" | "audio";
  url: string;
  thumb: string;
  name: string;
  duration?: number;
}

interface TrackClip {
  id: string;
  assetId: string;
  url: string;
  type: "video" | "audio" | "image";
  name: string;
  timelineStart: number;
  trimStart: number;
  trimEnd: number;
  maxDuration: number;
  opacity?: number;
  volume?: number;
  trackRow?: number;
}

interface TextLayer {
  id: string;
  text: string;
  x: number;
  y: number;
  fontSize: number;
  color: string;
  timelineStart: number;
  trimStart: number;
  trimEnd: number;
  maxDuration: number;
  opacity?: number;
  trackRow?: number;
}

export function VideoEditorUI() {
  const { clientId } = useClient();
  const router = useRouter();

  const [isPlaying, setIsPlaying] = useState(false);
  const [activeTab, setActiveTab] = useState<"assets" | "text">("assets");
  const [assetFilter, setAssetFilter] = useState<"library" | "sequence" | "audio">("library");

  const [isLoadingDB, setIsLoadingDB] = useState(false);
  const [assetPageLimit, setAssetPageLimit] = useState(8);
  const [hasMoreAssets, setHasMoreAssets] = useState(true);

  const [isRendering, setIsRendering] = useState(false);
  const [renderComplete, setRenderComplete] = useState(false);
  const [renderStatusText, setRenderStatusText] = useState("Preparing render engine...");
  const ffmpegRef = useRef(new FFmpeg());
  const [renderProgress, setRenderProgress] = useState(0);

  const [zoom, setZoom] = useState(2);
  const [globalTime, setGlobalTime] = useState(0);
  const [scrollLeft, setScrollLeft] = useState(0);

  const [isMagnetEnabled, setIsMagnetEnabled] = useState(true);

  const isScrubbingRef = useRef(false);
  const [isScrubbingUI, setIsScrubbingUI] = useState(false);

  const PIXELS_PER_SECOND = 10 * zoom;

  const [assets, setAssets] = useState<MediaAsset[]>([]);
  const [videoClips, setVideoClips] = useState<TrackClip[]>([]);
  const [audioClips, setAudioClips] = useState<TrackClip[]>([]);
  const [textLayers, setTextLayers] = useState<TextLayer[]>([]);

  const [selectedElement, setSelectedElement] = useState<{ id: string; type: "text" | "video" | "audio"; } | null>(null);
  const [hoveredTrackInfo, setHoveredTrackInfo] = useState<{ type: string, row: number } | null>(null);

  const videoTrackCount = Math.max(1, ...videoClips.map(c => (c.trackRow || 0) + 1));
  const textTrackCount = Math.max(1, ...textLayers.map(c => (c.trackRow || 0) + 1));
  const audioTrackCount = Math.max(1, ...audioClips.map(c => (c.trackRow || 0) + 1));

  const videoRefs = useRef<{ [id: string]: HTMLVideoElement | null }>({});
  // ✨ FIX: Allow HTMLVideoElement to be used for audio tracks so MP4s play perfectly
  const audioRefs = useRef<{ [id: string]: HTMLVideoElement | HTMLAudioElement | null }>({});

  const canvasRef = useRef<HTMLDivElement>(null);
  const timelineRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const dragTextRef = useRef<{ id: string; startX: number; startY: number; initX: number; initY: number; } | null>(null);
  const trimRef = useRef<{ id: string; type: "video" | "audio" | "text"; edge: "start" | "end"; startMouseX: number; initTrim: number; initTimeline: number; } | null>(null);
  const clipDragRef = useRef<{ id: string; type: "video" | "audio" | "text"; startMouseX: number; initTimelineStart: number; } | null>(null);

  async function loadDatabaseContent(limit: number, filterType: "library" | "sequence" | "audio") {
    if (!clientId) return;
    setIsLoadingDB(true);

    let query = supabase
      .from("content")
      .select("*")
      .eq("client_id", clientId)
      .order("created_at", { ascending: false })
      .limit(limit);

    if (filterType === "sequence") {
      query = query.eq("content_type", "sequence_clip");
    } else if (filterType === "audio") {
      query = query.in("content_type", ["generated_audio", "audio", "music", "voiceover"]);
    } else {
      query = query.not("content_type", "in", '("sequence_clip","generated_audio")');
    }

    const { data, error } = await query;

    if (data) {
      const dbAssets: MediaAsset[] = [];
      data.forEach((item) => {
        let parsedUrls: string[] = [];

        if (Array.isArray(item.image_urls) && item.image_urls.length > 0) {
          parsedUrls = item.image_urls;
        } else if (typeof item.image_urls === 'string' && item.image_urls.length > 5) {
          try { parsedUrls = JSON.parse(item.image_urls); } catch (e) { }
        }

        if (parsedUrls.length === 0) {
          if (Array.isArray(item.video_urls) && item.video_urls.length > 0) {
            parsedUrls = item.video_urls;
          } else if (typeof item.video_urls === 'string' && item.video_urls.length > 5) {
            try { parsedUrls = JSON.parse(item.video_urls); } catch (e) { }
          }
        }

        parsedUrls.forEach((url: string, idx: number) => {
          const isAudioUrl = url.includes(".mp3") || url.includes(".wav") || url.includes("audios/");
          const isAudioType = item.content_type === "generated_audio";
          const isAudio = isAudioUrl || isAudioType;

          const isVid = url.includes(".mp4") || url.includes(".mov") || item.content_type === "sequence_clip" || item.content_type === "reel";

          if (filterType === "audio" && !isAudio) return;
          if (filterType === "library" && (isAudio || item.content_type === "sequence_clip")) return;

          const mediaType = isAudio ? "audio" : isVid ? "video" : "image";

          dbAssets.push({
            id: `db-${item.id}-${idx}`,
            type: mediaType,
            url: url,
            thumb: url,
            name: item.caption || (isAudio ? `Voiceover/Music` : `${item.content_type || "Generated"} Media`),
          });
        });
      });
      setAssets(dbAssets);
      setHasMoreAssets(data.length >= limit);
    }
    setIsLoadingDB(false);
  }

  useEffect(() => {
    loadDatabaseContent(assetPageLimit, assetFilter);
  }, [clientId, assetPageLimit, assetFilter]);

  const handleFilterSwitch = (mode: "library" | "sequence" | "audio") => {
    setAssetFilter(mode);
    setAssetPageLimit(8);
    setAssets([]);
  };

  useEffect(() => {
    let animationFrameId: number;
    let lastTime = performance.now();

    function updatePlayhead(time: number) {
      if (isPlaying) {
        const deltaSeconds = (time - lastTime) / 1000;
        lastTime = time;

        setGlobalTime((prev) => {
          const nextTime = prev + deltaSeconds;
          const maxVideo = videoClips.length > 0 ? Math.max(...videoClips.map((c) => c.timelineStart + (c.trimEnd - c.trimStart))) : 0;
          const maxAudio = audioClips.length > 0 ? Math.max(...audioClips.map((c) => c.timelineStart + (c.trimEnd - c.trimStart))) : 0;
          const maxText = textLayers.length > 0 ? Math.max(...textLayers.map((c) => c.timelineStart + (c.trimEnd - c.trimStart))) : 0;
          const maxTime = Math.max(maxVideo, maxAudio, maxText, 5);

          if (nextTime >= maxTime) { setIsPlaying(false); return maxTime; }
          return nextTime;
        });
        animationFrameId = requestAnimationFrame(updatePlayhead);
      }
    }
    if (isPlaying) animationFrameId = requestAnimationFrame(updatePlayhead);
    return () => cancelAnimationFrame(animationFrameId);
  }, [isPlaying, videoClips, audioClips, textLayers]);

  useEffect(() => {
    videoClips.forEach(clip => {
      const el = videoRefs.current[clip.id];
      if (!el) return;
      const isActive = globalTime >= clip.timelineStart && globalTime < clip.timelineStart + (clip.trimEnd - clip.trimStart);
      if (isActive) {
        el.volume = (clip.volume ?? 100) / 100;
        const expectedTime = clip.trimStart + (globalTime - clip.timelineStart);
        if (Math.abs(el.currentTime - expectedTime) > 0.25) el.currentTime = expectedTime;
        if (isPlaying && el.paused) el.play().catch(() => { });
      } else {
        if (!el.paused) el.pause();
      }
    });

    audioClips.forEach(clip => {
      const el = audioRefs.current[clip.id];
      if (!el) return;
      const isActive = globalTime >= clip.timelineStart && globalTime < clip.timelineStart + (clip.trimEnd - clip.trimStart);
      if (isActive) {
        el.volume = (clip.volume ?? 100) / 100;
        const expectedTime = clip.trimStart + (globalTime - clip.timelineStart);
        if (Math.abs(el.currentTime - expectedTime) > 0.25) el.currentTime = expectedTime;
        if (isPlaying && el.paused) el.play().catch(() => { });
      } else {
        if (!el.paused) el.pause();
      }
    });
  }, [globalTime, videoClips, audioClips, isPlaying]);

  function togglePlay() {
    if (isPlaying) {
      setIsPlaying(false);
      Object.values(videoRefs.current).forEach(el => el?.pause());
      Object.values(audioRefs.current).forEach(el => el?.pause());
    } else {
      setIsPlaying(true);
    }
  }

  const getProxyUrl = (originalUrl: string) => {
    if (originalUrl.startsWith('blob:')) return originalUrl;
    return `/api/fetch-media?url=${encodeURIComponent(originalUrl)}`;
  };

  const handleRender = async () => {
    if (!clientId) return;
    const orderedVideos = [...videoClips].sort((a, b) => a.timelineStart - b.timelineStart);
    if (orderedVideos.length === 0) return alert("Please add at least one visual layer (image or video) to the timeline!");

    setIsRendering(true);
    setRenderComplete(false);
    setIsPlaying(false);
    setRenderProgress(5);
    setRenderStatusText("Booting AI Render Engine...");

    try {
      const ffmpeg = ffmpegRef.current;
      ffmpeg.on('log', ({ message }) => console.log('[FFmpeg]', message));

      if (!ffmpeg.loaded) {
        const baseURL = 'https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd';
        await ffmpeg.load({
          coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
          wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
        });
      }

      setRenderProgress(15);

      let hasFont = false;
      if (textLayers.length > 0) {
        setRenderStatusText("Loading font libraries...");
        try {
          const fontData = await fetchFile(getProxyUrl('https://raw.githubusercontent.com/ffmpegwasm/testdata/master/arial.ttf'));
          await ffmpeg.writeFile('arial.ttf', fontData);
          hasFont = true;
        } catch (e) {
          console.warn("Could not load font.", e);
        }
      }

      const inputArgs: string[] = [];
      const filterSteps: string[] = [];
      let concatStreams = "";

      for (let i = 0; i < orderedVideos.length; i++) {
        setRenderStatusText(`Processing visual media ${i + 1} of ${orderedVideos.length}...`);
        const clip = orderedVideos[i];
        const isImg = clip.type === 'image';
        const ext = isImg ? 'png' : 'mp4';
        const fileName = `media_${i}.${ext}`;
        const duration = clip.trimEnd - clip.trimStart;

        try {
          await ffmpeg.writeFile(fileName, await fetchFile(getProxyUrl(clip.url)));
        } catch (err) {
          throw new Error(`Failed to download media item ${i + 1}.`);
        }

        if (isImg) {
          inputArgs.push('-loop', '1', '-framerate', '30', '-t', String(duration), '-i', fileName);
        } else {
          inputArgs.push('-ss', String(clip.trimStart), '-t', String(duration), '-i', fileName);
        }

        filterSteps.push(`[${i}:v]scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2:color=black,setsar=1,fps=30,format=yuv420p[v${i}]`);
        concatStreams += `[v${i}]`;

        setRenderProgress(15 + Math.floor((i / orderedVideos.length) * 30));
      }

      setRenderStatusText("Stitching sequence...");
      filterSteps.push(`${concatStreams}concat=n=${orderedVideos.length}:v=1:a=0[outv]`);

      let finalVideoMap = '[outv]';

      if (textLayers.length > 0 && hasFont) {
        setRenderStatusText("Baking text layers...");
        let textFilters: string[] = [];
        textLayers.forEach((layer) => {
          const start = layer.timelineStart;
          const end = layer.timelineStart + (layer.trimEnd - layer.trimStart);
          const x = `(w*${layer.x}/100)`;
          const y = `(h*${layer.y}/100)`;
          const size = layer.fontSize * 2;
          const safeText = layer.text.replace(/'/g, "\u2019").replace(/:/g, "\\:");
          textFilters.push(`drawtext=fontfile=arial.ttf:text='${safeText}':fontcolor=${layer.color || 'white'}:fontsize=${size}:x=${x}:y=${y}:enable='between(t,${start},${end})'`);
        });
        if (textFilters.length > 0) {
          filterSteps.push(`[outv]${textFilters.join(',')}[textout]`);
          finalVideoMap = '[textout]';
        }
      }

      let hasAudio = false;
      if (audioClips.length > 0) {
        setRenderStatusText("Mixing and syncing audio layers...");

        if (audioClips.length === 1) {
          const clip = audioClips[0];

          // ✨ FIX: Extract real extension so FFmpeg doesn't corrupt MP4 audio containers
          const extMatch = clip.url.match(/\.([a-zA-Z0-9]+)(?:[\?#]|$)/);
          const rawExt = extMatch ? extMatch[1].toLowerCase() : 'mp3';
          const safeExt = ['mp4', 'mp3', 'wav', 'mov', 'webm', 'aac'].includes(rawExt) ? rawExt : 'mp3';

          const fileName = `audio_0.${safeExt}`;
          const duration = clip.trimEnd - clip.trimStart;
          await ffmpeg.writeFile(fileName, await fetchFile(getProxyUrl(clip.url)));

          inputArgs.push('-ss', String(clip.trimStart), '-t', String(duration), '-i', fileName);

          const delayMs = Math.floor(clip.timelineStart * 1000);
          const audioInputIndex = orderedVideos.length;
          filterSteps.push(`[${audioInputIndex}:a]adelay=${delayMs}|${delayMs}[outa]`);
          hasAudio = true;
        } else {
          let audioMixStr = "";
          for (let i = 0; i < audioClips.length; i++) {
            const clip = audioClips[i];

            // ✨ FIX: Extract real extension
            const extMatch = clip.url.match(/\.([a-zA-Z0-9]+)(?:[\?#]|$)/);
            const rawExt = extMatch ? extMatch[1].toLowerCase() : 'mp3';
            const safeExt = ['mp4', 'mp3', 'wav', 'mov', 'webm', 'aac'].includes(rawExt) ? rawExt : 'mp3';

            const fileName = `audio_${i}.${safeExt}`;
            const duration = clip.trimEnd - clip.trimStart;
            await ffmpeg.writeFile(fileName, await fetchFile(getProxyUrl(clip.url)));

            inputArgs.push('-ss', String(clip.trimStart), '-t', String(duration), '-i', fileName);

            const delayMs = Math.floor(clip.timelineStart * 1000);
            const audioInputIndex = orderedVideos.length + i;
            filterSteps.push(`[${audioInputIndex}:a]adelay=${delayMs}|${delayMs}[a${i}]`);
            audioMixStr += `[a${i}]`;
            hasAudio = true;
            setRenderProgress(40 + Math.floor((i / audioClips.length) * 20));
          }
          filterSteps.push(`${audioMixStr}amix=inputs=${audioClips.length}:duration=longest:dropout_transition=0[outa]`);
        }
      }

      setRenderProgress(70);
      const finalFilterGraph = filterSteps.join(';');

      const maxVideoTime = orderedVideos.reduce((max, clip) => Math.max(max, clip.timelineStart + (clip.trimEnd - clip.trimStart)), 0);

      setRenderStatusText("Encoding final masterpiece...");
      const execArgs = [
        ...inputArgs,
        '-filter_complex', finalFilterGraph,
        '-map', finalVideoMap
      ];

      if (hasAudio) {
        execArgs.push('-map', '[outa]');
        execArgs.push('-c:a', 'aac', '-b:a', '192k');
      }

      if (maxVideoTime > 0) {
        execArgs.push('-t', String(maxVideoTime));
      }

      execArgs.push('-c:v', 'libx264', '-preset', 'ultrafast', '-pix_fmt', 'yuv420p', 'output.mp4');

      const retCode = await ffmpeg.exec(execArgs);

      if (retCode !== 0) {
        throw new Error(`Engine failed (Exit code: ${retCode}).`);
      }

      setRenderProgress(90);
      setRenderStatusText("File successfully baked! Preparing download...");

      const data = await ffmpeg.readFile('output.mp4');
      if (data.length === 0) throw new Error("Render produced an empty file.");

      const finalBlob = new Blob([new Uint8Array(data as Uint8Array)], { type: 'video/mp4' });
      const localUrl = URL.createObjectURL(finalBlob);

      const downloadLink = document.createElement('a');
      downloadLink.href = localUrl;
      downloadLink.download = `Blink_Commercial_${Date.now()}.mp4`;
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);

      setRenderStatusText("Saving backup to your Content Grid...");

      const path = `videos/${clientId}/final_render_${Date.now()}.mp4`;
      await supabase.storage.from("assets").upload(path, finalBlob);
      const finalUrl = supabase.storage.from("assets").getPublicUrl(path).data.publicUrl;

      const { error } = await supabase.from('content').insert({
        client_id: clientId,
        content_type: 'reel',
        caption: '🎬 Final Edited Commercial',
        status: 'draft',
        video_urls: [finalUrl],
        image_urls: [finalUrl],
        ai_model: 'blink-wasm-editor'
      });

      if (error) throw error;

      setRenderProgress(100);
      setRenderComplete(true);

    } catch (err: any) {
      console.error("Render failed:", err);
      alert(`Render failed: ${err.message}`);
      setIsRendering(false);
      setRenderProgress(0);
      setRenderStatusText("");
    }
  };

  function handleDragStart(e: React.DragEvent, asset: MediaAsset) { e.dataTransfer.setData("application/json", JSON.stringify(asset)); }

  async function deleteAsset(assetId: string, assetName: string) {
    if (!confirm(`Are you sure you want to permanently delete "${assetName}"? This cannot be undone.`)) return;

    setAssets((prev) => prev.filter((a) => a.id !== assetId));

    if (assetId.startsWith('db-')) {
      const dbId = assetId.split('-')[1];

      const { error } = await supabase
        .from('content')
        .delete()
        .eq('id', dbId);

      if (error) {
        console.error("Failed to delete from Supabase:", error);
        alert("Failed to delete asset from the database.");
      }
    }
  }

  function handleManualUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const isAudio = file.type.includes("audio");
    const trackType = isAudio ? "audio" : file.type.includes("video") ? "video" : "image";
    processDroppedFile(file, trackType, globalTime, 0);
  }

  function processDroppedFile(file: File, trackType: "video" | "audio" | "image", dropTime: number, row: number) {
    const url = URL.createObjectURL(file);
    const newAsset: MediaAsset = { id: crypto.randomUUID(), type: trackType, url, thumb: url, name: file.name, duration: 10 };
    setAssets((prev) => [newAsset, ...prev]);
    addClipToTimeline(newAsset, trackType === "audio" ? "audio" : "video", dropTime, row);
  }

  function addClipToTimeline(asset: MediaAsset, trackType: "video" | "audio", dropTime: number, row: number) {
    const defaultDuration = asset.type === "image" ? 5 : asset.duration || 10;
    const newClip: TrackClip = {
      id: crypto.randomUUID(), assetId: asset.id, url: asset.url, type: asset.type as any, name: asset.name,
      timelineStart: dropTime, trimStart: 0, trimEnd: defaultDuration, maxDuration: defaultDuration,
      opacity: 100, volume: 100, trackRow: row,
    };
    if (trackType === "video") setVideoClips([...videoClips, newClip]);
    else setAudioClips([...audioClips, newClip]);
  }

  function handleDropOnTrack(e: React.DragEvent, trackType: "video" | "audio", targetRow: number) {
    e.preventDefault();
    setHoveredTrackInfo(null);
    const rect = e.currentTarget.getBoundingClientRect();
    const dropX = e.clientX - rect.left + (timelineRef.current?.scrollLeft || 0);
    const dropTime = Math.max(0, dropX / PIXELS_PER_SECOND);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      const isAudio = file.type.includes("audio");
      processDroppedFile(file, isAudio ? "audio" : file.type.includes("video") ? "video" : "image", dropTime, targetRow);
      return;
    }

    const data = e.dataTransfer.getData("application/json");
    if (!data) return;
    const asset = JSON.parse(data) as MediaAsset;
    if (trackType === "video" && asset.type === "audio") return alert("Please drop a video/image file here.");
    if (trackType === "audio" && asset.type !== "audio") return alert("Please drop an audio file here.");
    addClipToTimeline(asset, trackType, dropTime, targetRow);
  }

  function handleLoadedMetadata(id: string, duration: number, type: "video" | "audio") {
    if (isNaN(duration) || duration === Infinity) duration = 10;
    if (type === "video") setVideoClips((prev) => prev.map((c) => c.id === id ? { ...c, maxDuration: duration, trimEnd: Math.min(c.trimEnd, duration) } : c));
    else setAudioClips((prev) => prev.map((c) => c.id === id ? { ...c, maxDuration: duration, trimEnd: Math.min(c.trimEnd, duration) } : c));
  }

  const updateTextLayer = (id: string, updates: Partial<TextLayer>) => setTextLayers(prev => prev.map(l => l.id === id ? { ...l, ...updates } : l));
  const updateVideoClip = (id: string, updates: Partial<TrackClip>) => setVideoClips(prev => prev.map(c => c.id === id ? { ...c, ...updates } : c));
  const updateAudioClip = (id: string, updates: Partial<TrackClip>) => setAudioClips(prev => prev.map(c => c.id === id ? { ...c, ...updates } : c));

  function handleTimelineMouseDown(e: React.MouseEvent) {
    if (!timelineRef.current) return;
    isScrubbingRef.current = true;
    setIsScrubbingUI(true);
    setIsPlaying(false);

    const rect = timelineRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.left + timelineRef.current.scrollLeft;
    const exactDropX = clickX - 128;
    if (exactDropX >= 0) setGlobalTime(exactDropX / PIXELS_PER_SECOND);
  }

  function onTrimMouseDown(e: React.MouseEvent, id: string, type: "video" | "audio" | "text", edge: "start" | "end") {
    e.preventDefault(); e.stopPropagation();
    let clip: any = type === "video" ? videoClips.find((c) => c.id === id) : type === "audio" ? audioClips.find((c) => c.id === id) : textLayers.find((c) => c.id === id);
    if (!clip) return;
    trimRef.current = { id, type, edge, startMouseX: e.clientX, initTrim: edge === "start" ? clip.trimStart : clip.trimEnd, initTimeline: clip.timelineStart };
    setSelectedElement({ id, type });
  }

  function onClipMouseDown(e: React.MouseEvent, id: string, type: "video" | "audio" | "text") {
    e.stopPropagation();
    let clip: any = type === "video" ? videoClips.find((c) => c.id === id) : type === "audio" ? audioClips.find((c) => c.id === id) : textLayers.find((c) => c.id === id);
    if (!clip) return;
    clipDragRef.current = { id, type, startMouseX: e.clientX, initTimelineStart: clip.timelineStart };
    setSelectedElement({ id, type });
  }

  useEffect(() => {
    function onMouseMove(e: MouseEvent) {
      if (dragTextRef.current && canvasRef.current) {
        const currentDrag = dragTextRef.current;
        const rect = canvasRef.current.getBoundingClientRect();
        const dx = ((e.clientX - currentDrag.startX) / rect.width) * 100;
        const dy = ((e.clientY - currentDrag.startY) / rect.height) * 100;
        const newX = Math.min(95, Math.max(5, currentDrag.initX + dx));
        const newY = Math.min(95, Math.max(5, currentDrag.initY + dy));
        setTextLayers((prev) => prev.map((l) => l.id === currentDrag.id ? { ...l, x: newX, y: newY } : l));
      }

      if (trimRef.current) {
        const { id, type, edge, startMouseX, initTrim, initTimeline } = trimRef.current;
        const deltaSeconds = (e.clientX - startMouseX) / PIXELS_PER_SECOND;
        let setClips: any = type === "video" ? setVideoClips : type === "audio" ? setAudioClips : setTextLayers;

        setClips((prev: any[]) => prev.map((clip: any) => {
          if (clip.id !== id) return clip;
          let newClip = { ...clip };
          if (edge === "start") {
            const newTrim = Math.max(0, Math.min(initTrim + deltaSeconds, clip.trimEnd - 0.5));
            newClip.trimStart = newTrim;
            newClip.timelineStart = initTimeline + (newTrim - initTrim);
          } else {
            newClip.trimEnd = Math.max(clip.trimStart + 0.5, Math.min(clip.maxDuration, initTrim + deltaSeconds));
          }
          return newClip;
        }));
      }

      if (clipDragRef.current) {
        const { id, type, startMouseX, initTimelineStart } = clipDragRef.current;
        const deltaSeconds = (e.clientX - startMouseX) / PIXELS_PER_SECOND;
        let newTimelineStart = Math.max(0, initTimelineStart + deltaSeconds);

        let setClips: any = type === "video" ? setVideoClips : type === "audio" ? setAudioClips : setTextLayers;

        setClips((prev: any[]) => prev.map((clip: any) => {
          if (clip.id !== id) return clip;

          if (isMagnetEnabled) {
            const snapThreshold = 15 / PIXELS_PER_SECOND;
            let bestSnapDist = snapThreshold;
            let bestSnapTime = newTimelineStart;
            const duration = clip.trimEnd - clip.trimStart;

            const allClips = [...videoClips, ...audioClips, ...textLayers];

            allClips.forEach(other => {
              if (other.id === id) return;
              const otherStart = other.timelineStart;
              const otherEnd = other.timelineStart + (other.trimEnd - other.trimStart);

              if (Math.abs(newTimelineStart - otherEnd) < bestSnapDist) {
                bestSnapDist = Math.abs(newTimelineStart - otherEnd);
                bestSnapTime = otherEnd;
              }
              if (Math.abs(newTimelineStart - otherStart) < bestSnapDist) {
                bestSnapDist = Math.abs(newTimelineStart - otherStart);
                bestSnapTime = otherStart;
              }
              if (Math.abs((newTimelineStart + duration) - otherStart) < bestSnapDist) {
                bestSnapDist = Math.abs((newTimelineStart + duration) - otherStart);
                bestSnapTime = otherStart - duration;
              }
            });
            newTimelineStart = bestSnapTime;
          }

          return { ...clip, timelineStart: newTimelineStart };
        }));
      }

      if (isScrubbingRef.current) {
        if (!timelineRef.current) return;
        const rect = timelineRef.current.getBoundingClientRect();
        const clickX = e.clientX - rect.left + timelineRef.current.scrollLeft;
        const exactDropX = clickX - 128;
        if (exactDropX >= 0) setGlobalTime(exactDropX / PIXELS_PER_SECOND);
      }
    }

    function onMouseUp() {
      dragTextRef.current = null;
      trimRef.current = null;
      clipDragRef.current = null;

      if (isScrubbingRef.current) {
        isScrubbingRef.current = false;
        setIsScrubbingUI(false);
      }
    }

    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mouseup", onMouseUp);
    return () => { window.removeEventListener("mousemove", onMouseMove); window.removeEventListener("mouseup", onMouseUp); };
  }, [PIXELS_PER_SECOND, isMagnetEnabled, videoClips, audioClips, textLayers]);

  function addTextLayer() {
    const id = crypto.randomUUID();
    setTextLayers([...textLayers, {
      id, text: "New Text", x: 50, y: 50, fontSize: 48, color: "#FFFFFF",
      timelineStart: globalTime, trimStart: 0, trimEnd: 5, maxDuration: 3600, opacity: 100, trackRow: 0
    }]);
    setSelectedElement({ id, type: "text" });
    setActiveTab("text");
  }

  function deleteSelected() {
    if (!selectedElement) return;
    if (selectedElement.type === "text") setTextLayers((prev) => prev.filter((l) => l.id !== selectedElement.id));
    if (selectedElement.type === "video") setVideoClips((prev) => prev.filter((c) => c.id !== selectedElement.id));
    if (selectedElement.type === "audio") setAudioClips((prev) => prev.filter((c) => c.id !== selectedElement.id));
    setSelectedElement(null);
  }

  const contentMax = Math.max(30, ...videoClips.map((c) => c.timelineStart + (c.trimEnd - c.trimStart)), ...audioClips.map((c) => c.timelineStart + (c.trimEnd - c.trimStart)), ...textLayers.map((c) => c.timelineStart + (c.trimEnd - c.trimStart)), globalTime) + 60;
  const maxVisibleTime = Math.min(contentMax, 3600);

  let rulerStep = 1;
  if (zoom < 5) rulerStep = 5;
  if (zoom < 1) rulerStep = 30;
  if (zoom < 0.2) rulerStep = 60;

  return (
    <div className="flex flex-col h-[850px] bg-gray-50 border border-gray-200 rounded-2xl overflow-hidden shadow-sm select-none relative">

      {isRendering && (
        <div className="absolute inset-0 z-50 bg-gray-900/95 backdrop-blur-md flex flex-col items-center justify-center text-white animate-in fade-in duration-300">
          {!renderComplete ? (
            <>
              <Loader2 className="w-12 h-12 animate-spin text-purple-400 mb-6" />
              <h2 className="text-2xl font-bold tracking-widest uppercase mb-2">Rendering Sequence</h2>
              <p className="text-gray-400 text-sm mb-6 text-center max-w-sm">{renderStatusText}</p>

              <div className="w-64 h-2 bg-gray-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-purple-500 transition-all duration-300 ease-out"
                  style={{ width: `${renderProgress}%` }}
                />
              </div>
              <p className="text-xs text-purple-300 mt-2 font-bold">{renderProgress}%</p>
            </>
          ) : (
            <div className="flex flex-col items-center animate-in zoom-in duration-300">
              <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mb-6 shadow-[0_0_30px_rgba(34,197,94,0.4)]">
                <Check className="w-10 h-10 text-white" />
              </div>
              <h2 className="text-3xl font-bold tracking-widest uppercase mb-3">Render Complete!</h2>
              <p className="text-gray-300 text-base mb-8 text-center max-w-md leading-relaxed">
                Your video has been successfully downloaded to your computer and securely backed up to your Content Grid.
              </p>
              <div className="flex gap-4">
                <Button
                  onClick={() => { setIsRendering(false); setRenderComplete(false); }}
                  variant="outline"
                  className="border-gray-600 text-gray-300 hover:text-white hover:bg-gray-800 font-bold h-12 px-6"
                >
                  Back to Editor
                </Button>
                <Button
                  onClick={() => router.push('/dashboard/content')}
                  className="bg-purple-600 hover:bg-purple-700 text-white font-bold h-12 px-6 shadow-lg"
                >
                  View in Content Grid
                </Button>
              </div>
            </div>
          )}
        </div>
      )}

      <div className="flex flex-1 overflow-hidden">
        {/* LEFT PANEL: Media/Text */}
        <div className="w-72 bg-white border-r border-gray-200 flex flex-col z-10">
          <div className="flex border-b border-gray-100">
            <button onClick={() => setActiveTab("assets")} className={cn("flex-1 py-3 text-xs font-bold uppercase tracking-wider", activeTab === "assets" ? "text-purple-600 border-b-2 border-purple-600 bg-purple-50/50" : "text-gray-500 hover:bg-gray-50")}>Media</button>
            <button onClick={() => setActiveTab("text")} className={cn("flex-1 py-3 text-xs font-bold uppercase tracking-wider", activeTab === "text" ? "text-purple-600 border-b-2 border-purple-600 bg-purple-50/50" : "text-gray-500 hover:bg-gray-50")}>Text</button>
          </div>

          <div className="p-4 flex-1 overflow-y-auto custom-scrollbar">
            {activeTab === "assets" && (
              <div className="space-y-4">

                <div className="bg-gray-100 p-1 rounded-lg flex items-center justify-between">
                  <button
                    onClick={() => handleFilterSwitch('library')}
                    className={cn("flex-1 py-1.5 text-[11px] font-bold rounded-md transition-all", assetFilter === 'library' ? "bg-white shadow-sm text-gray-800" : "text-gray-500 hover:text-gray-700")}
                  >
                    General
                  </button>
                  <button
                    onClick={() => handleFilterSwitch('sequence')}
                    className={cn("flex-1 py-1.5 text-[11px] font-bold rounded-md transition-all flex items-center justify-center gap-1", assetFilter === 'sequence' ? "bg-white shadow-sm text-purple-700" : "text-gray-500 hover:text-gray-700")}
                  >
                    <Layers className="w-3 h-3" /> Scenes
                  </button>
                  <button
                    onClick={() => handleFilterSwitch('audio')}
                    className={cn("flex-1 py-1.5 text-[11px] font-bold rounded-md transition-all flex items-center justify-center gap-1", assetFilter === 'audio' ? "bg-white shadow-sm text-green-600" : "text-gray-500 hover:text-gray-700")}
                  >
                    <Mic className="w-3 h-3" /> Audio
                  </button>
                </div>

                <input type="file" ref={fileInputRef} className="hidden" accept="video/*,image/*,audio/*" onChange={handleManualUpload} />
                <Button onClick={() => fileInputRef.current?.click()} variant="outline" className="w-full border-dashed border-2 border-purple-200 text-purple-600 hover:bg-purple-50 h-10">
                  <UploadCloud className="w-4 h-4 mr-2" /> Upload File
                </Button>

                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <p className="text-xs font-bold text-gray-400 uppercase">
                      {assetFilter === 'library' && 'Your Library'}
                      {assetFilter === 'sequence' && 'Story Sequences'}
                      {assetFilter === 'audio' && 'AI Voiceovers'}
                    </p>
                    {isLoadingDB && <Loader2 className="w-3 h-3 text-purple-400 animate-spin" />}
                  </div>

                  <div className="grid grid-cols-2 gap-3 pb-2">
                    {assets.map((asset) => (
                      <div key={asset.id} draggable onDragStart={(e) => handleDragStart(e, asset)} className="group relative aspect-square bg-black rounded-lg overflow-hidden cursor-grab active:cursor-grabbing hover:ring-2 ring-purple-500 transition-all border border-gray-200">
                        {asset.type === "video" ? (
                          <video src={asset.url} className="w-full h-full object-cover opacity-80" preload="metadata" muted playsInline />
                        ) : asset.type === "audio" ? (
                          <div className="w-full h-full flex flex-col items-center justify-center bg-gray-900 border-2 border-green-500/30 text-green-400 group-hover:bg-gray-800 transition-colors">
                            <Mic className="w-8 h-8 mb-2 opacity-80" />
                            <span className="text-[10px] font-bold text-center w-full truncate px-2">{asset.name || "Voiceover"}</span>
                          </div>
                        ) : (
                          <img src={asset.thumb} alt="Asset" className="w-full h-full object-cover" />
                        )}

                        <div className="absolute top-1 left-1 bg-black/60 backdrop-blur-sm text-white p-1 rounded">
                          {asset.type === "video" ? <Video className="w-3 h-3" /> : asset.type === "audio" ? <Music className="w-3 h-3" /> : <ImageIcon className="w-3 h-3" />}
                        </div>
                        <button
                          onClick={() => deleteAsset(asset.id, asset.name)}
                          className="absolute top-1 right-1 bg-red-500 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 hover:bg-red-600 transition-opacity shadow-sm"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>

                  {assets.length === 0 && !isLoadingDB && (
                    <div className="text-center p-4 border-2 border-dashed border-gray-200 rounded-lg text-gray-400 text-xs">
                      {assetFilter === 'library' && 'No standard media found.'}
                      {assetFilter === 'sequence' && 'No sequences found. Generate a Storytelling B-Roll first!'}
                      {assetFilter === 'audio' && 'No voiceovers found. Use Dedicated TTS to generate one!'}
                    </div>
                  )}

                  {hasMoreAssets && assets.length > 0 && (
                    <Button
                      onClick={() => setAssetPageLimit(prev => prev + 8)}
                      variant="ghost"
                      className="w-full text-xs font-bold text-gray-500 hover:text-purple-600 border border-gray-200 bg-gray-50 hover:bg-purple-50 transition-colors mt-2"
                    >
                      {isLoadingDB ? <Loader2 className="w-3 h-3 animate-spin" /> : <ChevronDown className="w-3 h-3 mr-1" />} Load More
                    </Button>
                  )}
                </div>
              </div>
            )}
            {activeTab === "text" && (
              <div className="space-y-3">
                <Button onClick={addTextLayer} className="w-full bg-purple-50 text-purple-700 hover:bg-purple-100 border border-purple-200 justify-start font-bold text-lg h-14">
                  <Plus className="w-4 h-4 mr-2" /> Add Text Layer
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* CENTER PANEL: Preview Canvas */}
        <div className="flex-1 bg-gray-100 flex flex-col relative" onClick={() => setSelectedElement(null)}>
          <div className="h-12 bg-white border-b border-gray-200 flex items-center justify-between px-4 shrink-0">
            <span className="text-sm font-semibold text-gray-600">Preview Canvas</span>

            <Button
              size="sm"
              onClick={handleRender}
              disabled={isRendering || videoClips.length === 0}
              className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-md transition-all duration-200"
            >
              <Film className="w-4 h-4 mr-2" />
              Render & Finish
            </Button>
          </div>

          <div className="flex-1 overflow-hidden p-6 flex items-center justify-center bg-dot-pattern">
            <div ref={canvasRef} className="relative w-full max-w-3xl aspect-video bg-black rounded-lg shadow-2xl overflow-hidden ring-1 ring-white/10">

              {videoClips.sort((a, b) => (a.trackRow || 0) - (b.trackRow || 0)).map((clip) => {
                const isActive = globalTime >= clip.timelineStart && globalTime < clip.timelineStart + (clip.trimEnd - clip.trimStart);
                return (
                  <div
                    key={`canvas-${clip.id}`}
                    className="absolute inset-0 pointer-events-none transition-opacity duration-150"
                    style={{
                      opacity: isActive ? (clip.opacity ?? 100) / 100 : 0,
                      zIndex: clip.trackRow || 0,
                      display: isActive ? 'block' : 'none'
                    }}
                  >
                    {clip.type === "image" ? (
                      <img src={clip.url} className="w-full h-full object-contain" />
                    ) : (
                      <video
                        ref={el => { videoRefs.current[clip.id] = el; }}
                        src={clip.url}
                        className="w-full h-full object-contain"
                        playsInline
                      />
                    )}
                  </div>
                )
              })}

              {isScrubbingUI && (
                <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px] z-50 flex items-center justify-center pointer-events-none animate-in fade-in duration-150">
                  <div className="bg-black/60 px-4 py-2 rounded-full flex items-center gap-2 text-white/90 shadow-xl border border-white/10">
                    <Loader2 className="w-4 h-4 animate-spin text-purple-400" />
                    <span className="text-xs font-bold tracking-widest uppercase">Seeking...</span>
                  </div>
                </div>
              )}

              {!videoClips.some(clip => globalTime >= clip.timelineStart && globalTime < clip.timelineStart + (clip.trimEnd - clip.trimStart)) && (
                <div className="absolute inset-0 flex flex-col items-center justify-center text-gray-500 z-0">
                  <Video className="w-12 h-12 mb-2 opacity-30" />
                  <p>Drag a video or image to the timeline</p>
                </div>
              )}

              <div className="hidden">
                {videoClips.filter((c) => c.type === "video").map((clip) => (<video key={clip.id} src={clip.url} preload="metadata" onLoadedMetadata={(e) => handleLoadedMetadata(clip.id, e.currentTarget.duration, "video")} />))}

                {/* ✨ FIX: Render audio tracks through a hidden VIDEO tag so MP4 audio plays perfectly */}
                {audioClips.map((clip) => (
                  <video
                    key={`canvas-audio-${clip.id}`}
                    ref={el => { audioRefs.current[clip.id] = el; }}
                    src={clip.url}
                    preload="metadata"
                    onLoadedMetadata={(e) => handleLoadedMetadata(clip.id, e.currentTarget.duration, "audio")}
                  />
                ))}
              </div>

              {textLayers.sort((a, b) => (a.trackRow || 0) - (b.trackRow || 0)).map((layer) => {
                const isVisible = globalTime >= layer.timelineStart && globalTime < layer.timelineStart + (layer.trimEnd - layer.trimStart);
                if (!isVisible) return null;

                return (
                  <div
                    key={layer.id}
                    onMouseDown={(e) => { e.preventDefault(); e.stopPropagation(); setSelectedElement({ id: layer.id, type: "text" }); dragTextRef.current = { id: layer.id, startX: e.clientX, startY: e.clientY, initX: layer.x, initY: layer.y }; }}
                    style={{ top: `${layer.y}%`, left: `${layer.x}%`, color: layer.color, fontSize: `${layer.fontSize}px`, opacity: (layer.opacity ?? 100) / 100, zIndex: 100 + (layer.trackRow || 0) }}
                    className={cn(
                      "absolute transform -translate-x-1/2 -translate-y-1/2 font-bold whitespace-nowrap drop-shadow-[0_4px_4px_rgba(0,0,0,0.8)] cursor-grab active:cursor-grabbing px-2 py-1 rounded transition-opacity duration-150",
                      selectedElement?.id === layer.id ? "ring-2 ring-purple-500 ring-dashed bg-purple-500/20" : ""
                    )}
                  >
                    {layer.text}
                  </div>
                );
              })}
            </div>
          </div>

          <div className="h-14 bg-white border-t border-gray-200 flex items-center justify-center gap-4 shrink-0">
            <span className="text-xs font-mono w-16 text-right text-gray-500">{globalTime.toFixed(1)}s</span>
            <button onClick={() => setGlobalTime(0)} className="p-2 text-gray-600 hover:bg-gray-100 rounded-full"><SkipBack className="w-4 h-4" /></button>
            <button onClick={togglePlay} className="p-3 bg-purple-100 text-purple-700 hover:bg-purple-200 rounded-full transition-colors">
              {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current ml-0.5" />}
            </button>
            <span className="text-xs font-mono w-16 text-gray-500">{maxVisibleTime}s MAX</span>
          </div>
        </div>

        {/* RIGHT PANEL: INSPECTOR */}
        <div className="w-64 bg-white border-l border-gray-200 flex flex-col z-10 overflow-y-auto">
          <div className="p-4 border-b border-gray-100 flex items-center gap-2 bg-gray-50/50">
            <SlidersHorizontal className="w-4 h-4 text-gray-500" />
            <span className="font-bold text-sm text-gray-700">Properties</span>
          </div>

          {selectedElement ? (
            <div className="p-4 space-y-6 animate-in fade-in">
              <div className="flex items-center gap-2 pb-3 border-b border-gray-100">
                {selectedElement.type === 'video' && <Video className="w-4 h-4 text-blue-500" />}
                {selectedElement.type === 'audio' && <Music className="w-4 h-4 text-green-500" />}
                {selectedElement.type === 'text' && <Type className="w-4 h-4 text-purple-500" />}
                <span className="text-sm font-bold text-gray-700 capitalize">{selectedElement.type} Settings</span>
              </div>

              {selectedElement.type === "text" && (() => {
                const layer = textLayers.find(l => l.id === selectedElement.id);
                if (!layer) return null;
                return (
                  <div className="space-y-5">
                    <div>
                      <label className="text-[11px] font-bold text-gray-500 uppercase mb-1.5 block">Text Content</label>
                      <textarea value={layer.text} onChange={e => updateTextLayer(layer.id, { text: e.target.value })} className="w-full p-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm resize-none focus:ring-2 ring-purple-400 outline-none" rows={3} />
                    </div>
                    <div>
                      <label className="flex items-center justify-between text-[11px] font-bold text-gray-500 uppercase mb-1.5">
                        Font Size <span className="bg-gray-100 text-gray-700 px-1.5 py-0.5 rounded border border-gray-200">{layer.fontSize}px</span>
                      </label>
                      <input type="range" value={layer.fontSize} onChange={e => updateTextLayer(layer.id, { fontSize: parseInt(e.target.value) })} className="w-full accent-purple-600" min="12" max="120" />
                    </div>
                    <div>
                      <label className="flex items-center justify-between text-[11px] font-bold text-gray-500 uppercase mb-1.5">
                        Opacity <span className="bg-gray-100 text-gray-700 px-1.5 py-0.5 rounded border border-gray-200">{layer.opacity ?? 100}%</span>
                      </label>
                      <input type="range" value={layer.opacity ?? 100} onChange={e => updateTextLayer(layer.id, { opacity: parseInt(e.target.value) })} className="w-full accent-purple-600" min="0" max="100" />
                    </div>
                    <div>
                      <label className="text-[11px] font-bold text-gray-500 uppercase mb-1.5 block">Track Placement</label>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" className="flex-1" onClick={() => updateTextLayer(layer.id, { trackRow: Math.max(0, (layer.trackRow || 0) - 1) })}><ArrowUp className="w-4 h-4 mr-1" /> Up</Button>
                        <span className="w-10 flex items-center justify-center bg-purple-50 text-purple-700 font-bold rounded border border-purple-200 text-xs">T{(layer.trackRow || 0) + 1}</span>
                        <Button size="sm" variant="outline" className="flex-1" onClick={() => updateTextLayer(layer.id, { trackRow: (layer.trackRow || 0) + 1 })}><ArrowDown className="w-4 h-4 mr-1" /> Down</Button>
                      </div>
                    </div>
                  </div>
                );
              })()}

              {selectedElement.type === "video" && (() => {
                const clip = videoClips.find(c => c.id === selectedElement.id);
                if (!clip) return null;
                return (
                  <div className="space-y-5">
                    <div>
                      <label className="flex items-center justify-between text-[11px] font-bold text-gray-500 uppercase mb-1.5">
                        Opacity <span className="bg-gray-100 text-gray-700 px-1.5 py-0.5 rounded border border-gray-200">{clip.opacity ?? 100}%</span>
                      </label>
                      <input type="range" value={clip.opacity ?? 100} onChange={e => updateVideoClip(clip.id, { opacity: parseInt(e.target.value) })} className="w-full accent-blue-600" min="0" max="100" />
                    </div>
                    <div>
                      <label className="flex items-center justify-between text-[11px] font-bold text-gray-500 uppercase mb-1.5">
                        Volume <span className="bg-gray-100 text-gray-700 px-1.5 py-0.5 rounded border border-gray-200">{clip.volume ?? 100}%</span>
                      </label>
                      <input type="range" value={clip.volume ?? 100} onChange={e => updateVideoClip(clip.id, { volume: parseInt(e.target.value) })} className="w-full accent-green-600" min="0" max="100" />
                    </div>
                    <div>
                      <label className="text-[11px] font-bold text-gray-500 uppercase mb-1.5 block">Track Layer (Z-Index)</label>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" className="flex-1" onClick={() => updateVideoClip(clip.id, { trackRow: Math.max(0, (clip.trackRow || 0) - 1) })}><ArrowUp className="w-4 h-4 mr-1" /> Top</Button>
                        <span className="w-10 flex items-center justify-center bg-blue-50 text-blue-700 font-bold rounded border border-blue-200 text-xs">V{(clip.trackRow || 0) + 1}</span>
                        <Button size="sm" variant="outline" className="flex-1" onClick={() => updateVideoClip(clip.id, { trackRow: (clip.trackRow || 0) + 1 })}><ArrowDown className="w-4 h-4 mr-1" /> Bottom</Button>
                      </div>
                    </div>
                  </div>
                );
              })()}

              {selectedElement.type === "audio" && (() => {
                const clip = audioClips.find(c => c.id === selectedElement.id);
                if (!clip) return null;
                return (
                  <div className="space-y-5">
                    <div>
                      <label className="flex items-center justify-between text-[11px] font-bold text-gray-500 uppercase mb-1.5">
                        Volume <span className="bg-gray-100 text-gray-700 px-1.5 py-0.5 rounded border border-gray-200">{clip.volume ?? 100}%</span>
                      </label>
                      <input type="range" value={clip.volume ?? 100} onChange={e => updateAudioClip(clip.id, { volume: parseInt(e.target.value) })} className="w-full accent-green-600" min="0" max="100" />
                    </div>
                    <div>
                      <label className="text-[11px] font-bold text-gray-500 uppercase mb-1.5 block">Track Group</label>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" className="flex-1" onClick={() => updateAudioClip(clip.id, { trackRow: Math.max(0, (clip.trackRow || 0) - 1) })}><ArrowUp className="w-4 h-4 mr-1" /> Up</Button>
                        <span className="w-10 flex items-center justify-center bg-green-50 text-green-700 font-bold rounded border border-green-200 text-xs">A{(clip.trackRow || 0) + 1}</span>
                        <Button size="sm" variant="outline" className="flex-1" onClick={() => updateAudioClip(clip.id, { trackRow: (clip.trackRow || 0) + 1 })}><ArrowDown className="w-4 h-4 mr-1" /> Down</Button>
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-6 opacity-60">
              <SlidersHorizontal className="w-10 h-10 text-gray-300 mb-3" />
              <p className="text-sm font-medium text-gray-500">Select a clip or text layer on the timeline to adjust properties.</p>
            </div>
          )}
        </div>
      </div>

      {/* ─── BOTTOM WORKSPACE (Timeline Engine) ─── */}
      <div className="h-80 bg-white border-t border-gray-300 flex flex-col z-0">
        <div className="h-10 bg-gray-50 border-b border-gray-200 flex items-center justify-between px-4 z-20 shrink-0">
          <div className="flex items-center gap-2 text-gray-600">
            <span className="text-xs font-semibold uppercase text-gray-400 mr-4">Timeline Tracks</span>
            <button onClick={deleteSelected} disabled={!selectedElement} className="p-1.5 hover:bg-gray-200 rounded text-red-500 disabled:opacity-30 transition-colors"><Trash2 className="w-4 h-4" /></button>
          </div>
          <div className="flex items-center gap-3">

            <button
              onClick={() => setIsMagnetEnabled(!isMagnetEnabled)}
              className={cn("p-1.5 rounded transition-colors flex items-center gap-1", isMagnetEnabled ? "bg-purple-100 text-purple-600" : "text-gray-400 hover:bg-gray-100")}
              title={isMagnetEnabled ? "Snapping Enabled" : "Snapping Disabled"}
            >
              <Magnet className="w-4 h-4" />
            </button>
            <div className="w-px h-4 bg-gray-300 mx-1"></div>

            <ZoomOut className="w-4 h-4 text-gray-400" />
            <input type="range" min="0.1" max="20" step="0.1" value={zoom} onChange={(e) => setZoom(parseFloat(e.target.value))} className="w-32 accent-purple-500 h-1" />
            <ZoomIn className="w-4 h-4 text-gray-400" />
          </div>
        </div>

        <div className="flex-1 flex overflow-hidden relative bg-gray-50/50">

          <div className="w-32 flex-shrink-0 bg-white border-r border-gray-200 z-30 shadow-[2px_0_5px_-2px_rgba(0,0,0,0.1)] relative">
            <div className="h-6 border-b border-gray-200 bg-gray-50"></div>
            {Array.from({ length: videoTrackCount }).map((_, i) => (
              <div key={`vlabel-${i}`} className="h-14 border-b border-gray-100 flex items-center px-3 gap-2 text-gray-600 bg-blue-50/30">
                <Video className="w-4 h-4" /> <span className="text-xs font-semibold">V{i + 1}</span>
              </div>
            ))}
            {Array.from({ length: textTrackCount }).map((_, i) => (
              <div key={`tlabel-${i}`} className="h-12 border-b border-gray-100 flex items-center px-3 gap-2 text-gray-600 bg-purple-50/30">
                <Type className="w-4 h-4" /> <span className="text-xs font-semibold">T{i + 1}</span>
              </div>
            ))}
            {Array.from({ length: audioTrackCount }).map((_, i) => (
              <div key={`alabel-${i}`} className="h-14 border-b border-gray-100 flex items-center px-3 gap-2 text-gray-600 bg-green-50/30">
                <Music className="w-4 h-4" /> <span className="text-xs font-semibold">A{i + 1}</span>
              </div>
            ))}
          </div>

          <div
            ref={timelineRef}
            className="flex-1 overflow-x-auto relative custom-scrollbar"
            onMouseDown={handleTimelineMouseDown}
            onScroll={(e) => setScrollLeft(e.currentTarget.scrollLeft)}
          >
            <div style={{ width: `${maxVisibleTime * PIXELS_PER_SECOND}px`, minWidth: "100%", height: "100%", position: "relative" }}>

              <div className="h-6 border-b border-gray-200 bg-white sticky top-0 z-10 overflow-hidden pointer-events-none">
                {Array.from({ length: Math.ceil(maxVisibleTime / rulerStep) }).map((_, i) => (
                  <div key={i} className="absolute text-[9px] text-gray-400 border-l border-gray-300 pl-1" style={{ left: `${i * rulerStep * PIXELS_PER_SECOND}px`, bottom: 0, height: "12px" }}>{i * rulerStep}s</div>
                ))}
              </div>

              {Array.from({ length: videoTrackCount }).map((_, i) => (
                <div
                  key={`vrow-${i}`}
                  className={cn("h-14 border-b border-gray-200/50 relative py-1.5 transition-all", hoveredTrackInfo?.type === "video" && hoveredTrackInfo?.row === i ? "bg-blue-100 ring-2 ring-inset ring-blue-400" : "")}
                  onDragOver={(e) => { e.preventDefault(); setHoveredTrackInfo({ type: "video", row: i }); }}
                  onDragLeave={() => setHoveredTrackInfo(null)}
                  onDrop={(e) => handleDropOnTrack(e, "video", i)}
                >
                  {videoClips.filter(c => (c.trackRow || 0) === i).map((clip) => (
                    <div key={clip.id} onMouseDown={(e) => onClipMouseDown(e, clip.id, "video")} style={{ left: `${clip.timelineStart * PIXELS_PER_SECOND}px`, width: `${(clip.trimEnd - clip.trimStart) * PIXELS_PER_SECOND}px` }} className={cn("absolute top-1.5 h-11 bg-blue-200 border border-blue-400 rounded flex items-center overflow-hidden cursor-grab active:cursor-grabbing", selectedElement?.id === clip.id ? "ring-2 ring-blue-600 z-10 shadow-md" : "")}>
                      <div onMouseDown={(e) => onTrimMouseDown(e, clip.id, "video", "start")} className="w-2 h-full bg-blue-500 cursor-ew-resize shrink-0 hover:bg-blue-600" />
                      <span className="text-xs font-semibold text-blue-800 px-2 truncate flex-1 pointer-events-none">{clip.name}</span>
                      <div onMouseDown={(e) => onTrimMouseDown(e, clip.id, "video", "end")} className="w-2 h-full bg-blue-500 cursor-ew-resize shrink-0 hover:bg-blue-600" />
                    </div>
                  ))}
                </div>
              ))}

              {Array.from({ length: textTrackCount }).map((_, i) => (
                <div key={`trow-${i}`} className="h-12 border-b border-gray-200/50 relative py-1.5">
                  {textLayers.filter(l => (l.trackRow || 0) === i).map((layer) => (
                    <div key={layer.id} onMouseDown={(e) => onClipMouseDown(e, layer.id, "text")} style={{ left: `${layer.timelineStart * PIXELS_PER_SECOND}px`, width: `${(layer.trimEnd - layer.trimStart) * PIXELS_PER_SECOND}px` }} className={cn("absolute top-1.5 h-9 bg-purple-200 border border-purple-400 rounded flex items-center overflow-hidden cursor-grab active:cursor-grabbing", selectedElement?.id === layer.id ? "ring-2 ring-purple-600 z-10 shadow-md" : "")}>
                      <div onMouseDown={(e) => onTrimMouseDown(e, layer.id, "text", "start")} className="w-2 h-full bg-purple-500 cursor-ew-resize shrink-0 hover:bg-purple-600" />
                      <Type className="w-3 h-3 text-purple-700 mx-2 shrink-0 pointer-events-none" />
                      <span className="text-xs font-semibold text-purple-900 truncate flex-1 pointer-events-none">{layer.text}</span>
                      <div onMouseDown={(e) => onTrimMouseDown(e, layer.id, "text", "end")} className="w-2 h-full bg-purple-500 cursor-ew-resize shrink-0 hover:bg-purple-600" />
                    </div>
                  ))}
                </div>
              ))}

              {Array.from({ length: audioTrackCount }).map((_, i) => (
                <div
                  key={`arow-${i}`}
                  className={cn("h-14 border-b border-gray-200/50 relative py-1.5 transition-all", hoveredTrackInfo?.type === "audio" && hoveredTrackInfo?.row === i ? "bg-green-100 ring-2 ring-inset ring-green-400" : "")}
                  onDragOver={(e) => { e.preventDefault(); setHoveredTrackInfo({ type: "audio", row: i }); }}
                  onDragLeave={() => setHoveredTrackInfo(null)}
                  onDrop={(e) => handleDropOnTrack(e, "audio", i)}
                >
                  {audioClips.filter(c => (c.trackRow || 0) === i).map((clip) => (
                    <div key={clip.id} onMouseDown={(e) => onClipMouseDown(e, clip.id, "audio")} style={{ left: `${clip.timelineStart * PIXELS_PER_SECOND}px`, width: `${(clip.trimEnd - clip.trimStart) * PIXELS_PER_SECOND}px` }} className={cn("absolute top-1.5 h-11 bg-green-200 border border-green-400 rounded flex items-center overflow-hidden cursor-grab active:cursor-grabbing", selectedElement?.id === clip.id ? "ring-2 ring-green-600 z-10 shadow-md" : "")}>
                      <div onMouseDown={(e) => onTrimMouseDown(e, clip.id, "audio", "start")} className="w-2 h-full bg-green-500 cursor-ew-resize shrink-0 hover:bg-green-600" />
                      <Music className="w-3 h-3 text-green-700 mx-2 shrink-0 pointer-events-none" />
                      <span className="text-xs font-semibold text-green-800 truncate flex-1 pointer-events-none">{clip.name}</span>
                      <div onMouseDown={(e) => onTrimMouseDown(e, clip.id, "audio", "end")} className="w-2 h-full bg-green-500 cursor-ew-resize shrink-0 hover:bg-green-600" />
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>

          <div className="absolute top-0 bottom-0 pointer-events-none z-50 overflow-hidden" style={{ left: '8rem', right: 0 }}>
            <div
              className="absolute top-0 bottom-0 w-0.5 bg-red-500 will-change-transform"
              style={{ transform: `translateX(${(globalTime * PIXELS_PER_SECOND) - scrollLeft}px)` }}
            >
              <div className="absolute -top-0 -left-1.5 w-3 h-3 bg-red-500 rounded-sm shadow-md"></div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}